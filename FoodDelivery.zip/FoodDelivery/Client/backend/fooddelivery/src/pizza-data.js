const pizzas = [
    {
      name: "Tomato Basil Italian Pizza",
      price:`450 Rs`,
      image: "/images/margherita.jpg",
      description: "Dressed with oil, the origanum and garlic cloves shredded minutely. Fresh tomato sauce with Parmesan cheese, jalapeno peppers, red peppers.",
    },
    {
      name: "Bombay Pizza",
      price:`450 Rs`,
      image: "/images/farmhouse.jpg",
      description:
        "Spicy tomato sauce withe italian herbs, mushrooms, onion, cottage cheese, coriander and mozzarelia.",
    },
    {
      name: "Sicilia Pizza",
      price:`450 Rs`,
      image: "/images/veggie_paradise.jpg",
      description:
        "A thick base pizza with fresh tomato sauce, mushrooms, garlic, pickled onions.",
    },
  ];
  export default pizzas;
  