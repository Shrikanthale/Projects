const opt = [
    {
      name: "Pizza",
      image: "/images/margherita.jpg",},
    {
      name: "Burger",
      image: "/images/farmhouse.jpg",
      },
  ];
  export default opt;
  